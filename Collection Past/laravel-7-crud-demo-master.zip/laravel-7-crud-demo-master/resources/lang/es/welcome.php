<?php

return [

    // language file for welcome view

    'home' => 'Casa',
    'login' => 'Iniciar sesión',
    'register' => 'Registro',
    'created-by' => 'Creado por',
    'go-to-home' => 'Ir a casa',
    'login-to-begin' => 'Iniciar sesión para comenzar',
    'view-readme' => 'Leer Readme',
    'switch-lang' => 'switch to english',
];
