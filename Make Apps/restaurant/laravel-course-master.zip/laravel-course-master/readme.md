<p align="center"><img src="https://laravel.com/assets/img/components/logo-laravel.svg"></p>

Full source code of the Laravel Essentials course on Udemy

**[Get it here!](https://www.udemy.com/laravel-beginner-fundamentals/?couponCode=SOURCE_CODE)**

## Laravel Essentials Course on Udemy

This repository contains the full source code of the upcoming Udemy course.

For each lecture there is a separate branch with changes made during that lecture to clone or download.

The course is live now, get if with a discount (9.99\$):

**[Get it here!](https://www.udemy.com/laravel-beginner-fundamentals/?couponCode=SOURCE_CODE)**
