<?php

return [

    // language file for welcome view

    'home' => 'Home',
    'login' => 'Login',
    'register' => 'Register',
    'created-by' => 'Created by',
    'go-to-home' => 'Go to Home',
    'login-to-begin' => 'Login to Begin',
    'view-readme' => 'View Readme',
    'switch-lang' => 'cambio al español',

];
