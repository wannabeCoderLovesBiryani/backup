@extends('layout')

@section('content')
  <h1>Secret Page!</h1>
  <p>This is a secret email secre@laravel.test</p>
@endsection