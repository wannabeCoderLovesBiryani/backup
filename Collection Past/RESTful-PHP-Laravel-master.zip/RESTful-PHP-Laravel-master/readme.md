# RESTful Web Services with PHP and Laravel
by Max Schwarzmueller

## Code Exercice 
by Emanuel Limeira

## Description
In today's web application environment, RESTful services play a very important role. This course teaches you how to create such services with one of the most popular PHP frameworks: Laravel.

## Buy Subscription
Pay a Subscription [Pluralsight](pluralsight.com)

## This Repo
This files is a compilation created for myself. Enjoy! ;)

June 2016 / [Emanuel Limeira](https://emanuellimeira.com.br)