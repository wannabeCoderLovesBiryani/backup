<?php

return [

    'Company' => 'Entreprise',
    'Employee' => 'Employé',
    'action' => 'action',
    'CompanyName'   => 'Nom d`Entreprise',        
    'Email'        => 'Email',       
    'Logo' => 'Logo',
    'Website' => 'Website',


    
    'first_name' => 'Prénom',
    'last_name' => 'Nom',
    'phone_number' => 'Numero Tel',
];
