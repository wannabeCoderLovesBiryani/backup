@extends('layouts.app')

@section('content')
This is the index of the PagesController.
@endsection
