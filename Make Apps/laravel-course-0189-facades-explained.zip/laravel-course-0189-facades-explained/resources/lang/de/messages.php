<?php
	
return [
    'people.reading' => '{0} Derzeit von niemandem gelesen|{1} Derzeit von :count Person gelesen|[2,*] Derzeit von :count Personen gelesen',
    'comments' => '{0} Noch keine Kommentare|{1} :count Kommentar|[2,*] :count Kommentare'
]; 
