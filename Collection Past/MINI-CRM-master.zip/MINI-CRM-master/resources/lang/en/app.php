<?php

return [

    'Company' => 'Companies',
    'Employee' => 'Employee',
    'action' => 'action',
   'CompanyName'   => 'Company Name',        
    'Email'        => 'Email',       
    'Logo' => 'Logo',
    'Website' => 'Website',
    

    'first_name' => 'First Name',
    'last_name' => 'Last Name',
    'phone_number' => 'Phone Number',

];
