<?php
	
return [
    'people.reading' => '{0} Actualmente leído por nadie|{1} Actualmente leído por :count persona|[2,*] Actualmente leído por :count personas',
    'comments' => '{0} Sin comentarios aún|{1} :count comentario|[2,*] :count comentarios'
]; 
