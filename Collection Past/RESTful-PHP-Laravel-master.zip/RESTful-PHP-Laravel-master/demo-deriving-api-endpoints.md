Demo: Deriving API Endpoints

# Meeting Scheduler API
Users should be able to create, update, and delete meetings.
Furthermore, other users should be able to register and unregister 
for any created meetings. Lastly, it should be possible to retrieve a
lista of all meetings or data about an individual meeting.

## Meeting Scheduler
- Create Meeting
- Update Meeting
- Delete Meeting

- Register for Meeting
- Unregister from Meeting

- Create User

- Get List of all Meetings
- Get Data about individual Meeting




June 2016 / [Emanuel Limeira](https://emanuellimeira.com.br)