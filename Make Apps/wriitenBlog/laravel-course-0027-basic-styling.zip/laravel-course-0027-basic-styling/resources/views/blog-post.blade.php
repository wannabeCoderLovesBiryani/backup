@extends('layout')

@section('content')
    {!! $welcome !!}{{ $data['title'] }}
@endsection('content')