<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class AuthController extends Controller
{
    public function store(Request $request)
    {
        return "It works!";
    }

    public function signin(Request $request)
    {
        return "It works!";
    }
}
