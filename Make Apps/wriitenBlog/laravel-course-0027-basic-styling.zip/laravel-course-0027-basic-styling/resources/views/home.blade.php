@extends('layout')

@section('content')
<h1>Welcome to Laravel!</h1>

<p>This is the content of the main page!</p>
@endsection